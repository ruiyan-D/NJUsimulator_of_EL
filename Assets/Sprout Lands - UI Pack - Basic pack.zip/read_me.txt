
 Heyo! Thanks for downloading the Sprout Lands Basic UI pack !!! 
 - Made by: Cup Nooble 

 This asset pack is the start of a series of different asset packs, 
 so let me know if there are any specific sprites you'd like to be added in future packs.

-------------------------------------------------------------------------------------------------------------

 >>> License - Basic UI Pack

 ----------

 - You can modify the assets. 

 [ Feel free to get creative and make your own sprites in this style or use them as reference for your own ]
 [ Making additional sprites in the same style or using them as reference for your own project is also allowed ]
 
 ----------

 - You can use these assets in any kind of non-commercial projects. 

 [ Except anything to do with NFTs or AI training is not allowed ]

 ----------

 - You can not redistribute the asset pack itself or resell it on other platforms, even if it is slightly modified.

 [ Of course, you can redistribute your own projects made with these assets like games, software, or other ]
 [ Making your project opensource is also allowed ]
 [ For open source projects include a note that says some or all assets are made by Cup Nooble together with the licensing terms ]

 ----------

 - Credit is required : (Cup Nooble) 

 [ Credit example : Assets -From : Sprout Lands -By : Cup Nooble ]
 [ If you share your game on itch.io a link to the Asset Packs page would be very appreciated ]
 [ But feel free to credit in whatever way fits your project best ]
 [ Thanks a lot for reading ^^ ]

 ----------

 ~ And most importantly hope you have fun with your project !!!
 
 ? And if you have questions or need/want different licensing terms please reach out to me and I can work with you on a license that suits your needs.
 My Discord : cup_nooble

-------------------------------------------------------------------------------------------------------------

 >>> See updates here :

 - Discord server :
   Join The Sprout Lands Discord for any hotfixes and updates or for any questions
   Link - https://discord.gg/PyDwcnPY

 - Twitter :
   Link - https://twitter.com/Sprout_Lands

-------------------------------------------------------------------------------------------------------------
 
 >>> Support 

 If you enjoy this asset pack consider leaving a rating and a comment. 
 It really helps to support the future of this project ^u^!

 ----------

 Want to find more from Cup Nooble ?
 check out their link tree - cupnooble.carrd.co
